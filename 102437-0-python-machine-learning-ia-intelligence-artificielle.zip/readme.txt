Python Machine Learning - IA - Intelligence Artificielle--------------------------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/102437-python-machine-learning-ia-intelligence-artificielleAuteur  : ciddu42Date    : 19/11/2019
Licence :
=========

Ce document intitul� � Python Machine Learning - IA - Intelligence Artificielle � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

<b>Python Machine Learning - IA - Intelligence Artificielle :</b>
<br />Voici u
n code source de réseau de neurones permettant l'apprentissage et la
<br />rec
onnaissance de formes. Le Machine Learning fonctionne à l'aide d'un réseau de

<br />neurones artificiels de type perceptron monocouche à apprentissage super
visé. La
<br />reconnaissance des formes déssinées est en temps réel. Le co
de a été organisé en
<br />suivant le design pattern : &quot;model view pres
enter&quot;, permettant de découper et de
<br />structurer l'architecture de l
'interface utilisateur en couches. L'interface 
<br />graphique est réalisé a
vec Tkinter, l'application fonctionne sous Windows ou
<br />Linux.
<br />
<br
 />
<br />---------------------------------------------------------------------
--------------------------------------------------------------------------------
----
<br />
<br /><b>La version de ce code source en C est disponible ici :</b
>
<br /><a href='https://codes-sources.commentcamarche.net/source/102467-c-mach
ine-learning-ia-intelligence-artificielle'>https://codes-sources.commentcamarche
.net/source/102467-c-machine-learning-ia-intelligence-artificielle</a>
<br />

<br />--------------------------------------------------------------------------
-------------------------------------------------------------------------------

<br />
<br />
<br /><b>1 - Suivis des versions :</b>
<br />    <b>- version 
14/08/19 :</b>
<br />      code prêt à l'emploi mais pas encore commenté.
<
br />
<br />    <b>- version 04/09/19 :</b>
<br />      ajout de la possibilit
é de créer des variantes aux formes enregistrées. 
<br />      Des correctio
ns, ajouts de fonctionnalités, et améliorations pour la 
<br />      lisibili
té du code sont toujours en cours.
<br />
<br />
<br /><b>2 - outils nécess
aires pour faire fonctionner l'application :</b>
<br />    <b>Sous Windows :</b
>
<br />        version minimum de Python installée : 3.6
<br />        modul
es Python intallés : Dill
<br />        Executer : py Machine Learning.pyw
<b
r />
<br />    <b>Sous Linux :</b>
<br />        version minimum de Python ins
tallée : 3.6
<br />        paquets supplémentaires nécessaires :
<br />    
        python3-dev python3-tk python3-pip
<br />        modules Python intall�
�s : setuptools Dill
<br />        Executer : python Machine Learning.pyw
<br 
/>
<br />
<br /><b>3 - Fonctionnement de l'application :</b>
<br />    <b>- C
adre &quot;Forme déssinée&quot; :</b>
<br />        clique gauche de la souri
s -&gt; créer un pixel
<br />        clique droit de la souris -&gt; éffacer 
un pixel précédemment créé
<br />        tour de la molette -&gt; changer l
e nom de la forme à corriger
<br />        clique sur la molette -&gt; corrige
r la forme sélectionnée
<br />        
<br />        <span style='text-decor
ation: underline;'>- Avec touche Ctrl gauche appuyé :</span>
<br />        tou
r de la molette -&gt; changer la forme enregistrée affichée
<br />        cli
que sur la molette -&gt; crée une variante à la forme enregistrée affichée

<br />        
<br />        <span style='text-decoration: underline;'>- Avec t
ouche Ctrl gauche et shift gauche appuyés :</span>
<br />        tour de la mo
lette -&gt; changer la variante de la forme enregistrée affichée
<br />      
  
<br />        
<br />    <b>- Cadre &quot;Forme reconnue&quot; :</b>
<br /
>        Affiche la forme reconnue.
<br />        
<br />    <b>- Bouton &quot
;Apprentissage automatique&quot; :</b>
<br />        le réseau de neurones app
rend les formes jusqu'à ce qu'il les reconnaisse 
<br />        toutes telles 
qu'elles ont été déssinnées lors de leurs création.
<br />        ce bouto
n est à utiliser de préférence une fois toutes les formes
<br />        cré
ées ou quand le réseau de neurones a un taux d'érreur trop élevé.
<br />  
      
<br />    <b>- Bouton &quot;Corriger&quot; :</b>
<br />        sert à 
apprendre une forme légèrement différente de la forme déssinée 
<br />    
    lors de sa création.
<br />        ex: on dessine une lettre 'A' qui a seu
lement 3 pixels de différence 
<br />        avec la lettre 'A' que l'on avait
 créée précédemment, mais le réseau 
<br />        de neurones reconnait u
ne autre lettre. Dans ce cas on sélectionne 
<br />        le nom de la lettre
 à corriger dans la combo box &quot;nom de la forme à 
<br />        corriger
&quot; puis on clique sur corriger, le réseau va alors corriger les
<br />    
    neurones et va reconnaitre alors la bonne lettre: 'A'. Au bout de 
<br />  
      quelques itérations le reseau de neurones reconnaitra à 
<br />        
presque 100% (voire même 100%) toutes les formes créées et leurs variantes.

<br />        
<br />    <b>- Bouton &quot;Ajouter&quot; :</b>
<br />        c
rée une variante à la forme enregistrée selectionnée.
<br />        
<br /
>    <b>- Entrée &quot;maximum d'itérations&quot; :</b>
<br />        nombre 
maximum de corrections effectuées lors d'un apprentissage
<br />        automa
tique du réseau de neurones: doit rester bas de préférence
<br />        lor
s d'un apprentissage d'une grande quantité de formes créées pour
<br />     
   ne pas paralyser l'application.
<br />        
<br />    <b>- Entrée &quot
;valeur de correction&quot; :</b>
<br />        valeur utilisée pour chaque co
rrection de neurones lors de 
<br />        l'apprentissage du réseau de neuro
nes: doit être positive et rester
<br />        basse de préference pour un a
pprentissage rapide.
<br />
<br />
<br /><b>4 - Autres détails :</b>
<br />
    Si jamais vous rencontrez un problème avec l'application, ou si vous avez 

<br />    des suggestions : n'hésitez pas à me le dire dans les commentaires.
